CALCULADORA DE COMISIONES — RUMBO A PLATINO
Proyecto Android basado en la versión V4 con logo.

REQUISITOS
- Android Studio reciente
- JDK 17
- Android SDK Platform 35
- Conexión a internet durante la primera sincronización de Gradle

COMPILAR APK
1. Descomprime este ZIP.
2. Abre la carpeta CalculadoraComisionesAndroid desde Android Studio.
3. Espera a que Gradle sincronice y descargue dependencias.
4. En Android Studio selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en app/build/outputs/apk/debug/app-debug.apk.

La aplicación carga los archivos locales incluidos en app/src/main/assets/www.
No requiere conexión a internet para sus funciones de cálculo.
