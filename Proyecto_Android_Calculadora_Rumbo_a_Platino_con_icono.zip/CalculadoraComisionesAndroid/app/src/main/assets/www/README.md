# Calculadora de Comisiones Izzi — prototipo actualizado

## Cambios
- Se eliminó la selección de Cambaceo/Módulos: se utiliza el mismo esquema para ambos.
- Se eliminó la lista fija de productos.
- El vendedor agrega ventas y selecciona 1P, 2P, 3P o 4P.
- En cada renglón escribe manualmente el ARPU y la cantidad de ventas instaladas.
- Se conserva la selección manual de categoría y el acelerador M1.
- Casilla opcional de izzi TV+ para sumar 5 puntos porcentuales al factor.
- Se pueden agregar o quitar renglones para representar diferentes ARPU.

## Fórmula
Comisión por renglón = ARPU × factor del bracket (más 5 puntos porcentuales si se marca izzi TV+) × cantidad.
Al subtotal se le aplica M1: +5%, -5% o sin ajuste.

## Factores del esquema
BASE: 1P 20%, 2P 25%, 3P 30%, 4P 35%
BRONCE: 1P 42%, 2P 53%, 3P 57%, 4P 61%
PLATA: 1P 50%, 2P 65%, 3P 70%, 4P 75%
ORO: 1P 65%, 2P 80%, 3P 85%, 4P 90%
PLATINO: 1P 85%, 2P 105%, 3P 115%, 4P 125%

## Instalación
Abre index.html en un navegador. Para instalar como PWA en Android, publica la carpeta en HTTPS y usa Chrome → menú → Instalar aplicación.

## Alcance
Estimación sobre ventas instaladas por brackets. No incluye domiciliación, portabilidad, móvil, conciliaciones ni reglas especiales de nuevos ingresos porque el esquema fuente no detalla todos los importes/condiciones.
